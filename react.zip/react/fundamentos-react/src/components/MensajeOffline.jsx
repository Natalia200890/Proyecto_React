import PropTypes from "prop-types";

const MensajeOffline = () => {
    return <h3>Usuario desconectado</h3>;
  };

  export default MensajeOffline; 