import PropTypes from "prop-types";

const MensajeOnline = () => {
    return <h3>Bienvenido usuario</h3>;
  };
export default MensajeOnline; 